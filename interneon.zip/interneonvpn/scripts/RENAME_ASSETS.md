He creado este archivo para documentar archivos que requieren renombrado manual (binarios).

Archivos con nombre antiguo:
- "Documentación del Proyecto ShadowGuard VPN.docx"
- "Proyecto ShadowGuard Vpn By IkuDev.pdf"

Acción recomendada:
1. Abre la carpeta del proyecto.
2. Renombra manualmente los archivos anteriores a:
   - "Documentación del Proyecto InterNeon VPN.docx"
   - "Proyecto InterNeon VPN By IkuDev.pdf"

Nota: No modifiqué el contenido binario. Si quieres que cree copias con los nuevos nombres, sube los archivos o dime si quieres que los mueva/renombre localmente (requiere permiso de sistema de archivos fuera de este editor).
